create
    definer = rdsadmin@localhost procedure new_privilege_model(IN username varchar(255))
begin
    declare user_exist bool default NULL;
    select 1 into user_exist from mysql.user where concat("'", user, "'@'", host, "'") = username;
	if user_exist is NULL then
	  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User does not exist!';
	end if;
	if current_user() <> 'rdsadmin@localhost' then
	  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This procedure needs to run from rdsadmin';
	end if;

    
	GRANT SYSTEM_USER, ROLE_ADMIN on *.* TO rdsadmin@localhost WITH GRANT OPTION ;
	CREATE ROLE IF NOT EXISTS rds_superuser_role@`%`;
	GRANT SELECT, INSERT, UPDATE, DELETE, CREATE, DROP, RELOAD, PROCESS, REFERENCES, 
	INDEX, ALTER, SHOW DATABASES, CREATE TEMPORARY TABLES, LOCK TABLES, EXECUTE, 
	REPLICATION SLAVE, REPLICATION CLIENT, CREATE VIEW, SHOW VIEW, 
	CREATE ROUTINE, ALTER ROUTINE, 
	CREATE USER, EVENT, TRIGGER, CREATE TABLESPACE, CREATE ROLE, DROP ROLE 
	ON *.* TO `rds_superuser_role`@`%` WITH GRANT OPTION;
	GRANT APPLICATION_PASSWORD_ADMIN,CONNECTION_ADMIN,ROLE_ADMIN,SET_USER_ID,
	XA_RECOVER_ADMIN ON *.* TO `rds_superuser_role`@`%` WITH GRANT OPTION;
	GRANT INSERT, UPDATE, DELETE, SELECT ON mysql.plugin TO `rds_superuser_role`@`%`;
    
    set global partial_revokes=1;
	REVOKE INSERT, UPDATE, DELETE, CREATE, DROP, INDEX, ALTER, 
    CREATE TEMPORARY TABLES, CREATE VIEW, CREATE ROUTINE, ALTER ROUTINE 
    ON `mysql`.* FROM `rds_superuser_role`@`%`;

	select user, host from mysql.user where user = 'rds_superuser_role';
	SET @s = CONCAT('revoke all on *.* from ', username);
	select @s;
	PREPARE stmt FROM @s;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
	SET @s = CONCAT('grant rds_superuser_role to ', username);
	select @s;
	PREPARE stmt FROM @s;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    SET @s = CONCAT('SET DEFAULT ROLE rds_superuser_role to ', username);
	select @s;
	PREPARE stmt FROM @s;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;

    
    UPDATE mysql.user set User_attributes = 
    JSON_MERGE_PATCH(User_attributes, 
    '{"Restrictions": [{"Database": "mysql", "Privileges": 
    ["INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "INDEX", "ALTER", 
    "CREATE TEMPORARY TABLES", "LOCK TABLES", "CREATE VIEW", "CREATE ROUTINE", 
    "ALTER ROUTINE"]}]}') 
    WHERE concat(user, '@', host) 
    NOT IN ('rdsadmin@localhost', 'rdsrepladmin@%', 
    'mysql.infoschema@localhost', 'mysql.session@localhost', 'mysql.sys@localhost');
    flush privileges;
    select 'done!';
end;

